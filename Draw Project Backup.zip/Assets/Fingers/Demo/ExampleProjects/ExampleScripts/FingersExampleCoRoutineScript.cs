﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace DigitalRubyShared
{
    public class FingersExampleCoRoutineScript : MonoBehaviour
    {
    }
}