﻿To run an example project, set the play scene on the Main Menu Scene on the main menu script on the Canvas object.
Also, ensure that any scenes you want to transition to are included in the scene list of the build settings.

When building your scenes, make sure to make each scene have it's own camera, own canvas and an event system inside the canvas.